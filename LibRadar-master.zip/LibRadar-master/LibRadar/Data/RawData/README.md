# Raw Data

This directory is used for store raw data from outside.
Data here could be token as known conditions.

# Content

From android7.jar to android25.jar

# Quick Start

 - Download Android SDK using *Android SDK Manager*.
 - Select SDK Platform for each version(API Level).
 - Open your path of SDK. (e.g. ~/Android/Sdk/platforms)
 - Copy android.jar into libradar/Data/RawData and rename it.

```bash
cp ~/Android/Sdk/platform/android-21/android.jar $LibRadar_Folder$/Data/RawData/android21.jar
```
