# -*- coding: utf-8 -*-

import os
import commands


"""

    Test 2016-12-01 1

    usage of jad and commands


cmd = "jadc"
status, out = commands.getstatusoutput('jasdcs')
print "OUTPUT is "
print out
print status
"""

"""

    Test 2016-12-02 1



"""

import redis

r = redis.StrictRedis()
r.set('name', 'zachary marv')
print r.get('man')