import logging



logging.warning("hongda!")
logging.error("Info")
logging.critical('critical message')